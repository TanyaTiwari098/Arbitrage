
import asyncio
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
import uvicorn
from arbitrage_bot import ArbitrageBot
import json

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('arbitrage_bot.log'),
        logging.StreamHandler()
    ]
)

# Global bot instance
bot = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    global bot
    bot = ArbitrageBot()
    asyncio.create_task(bot.start())
    yield
    # Shutdown
    if bot:
        bot.running = False

app = FastAPI(title="Crypto Arbitrage Bot", lifespan=lifespan)
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})

@app.get("/api/balances")
async def get_balances():
    if bot:
        return await bot.get_all_balances()
    return {"error": "Bot not initialized"}

@app.get("/api/prices")
async def get_prices():
    if bot:
        return await bot.get_current_prices()
    return {"error": "Bot not initialized"}

@app.get("/api/opportunities")
async def get_opportunities():
    if bot:
        return bot.get_arbitrage_opportunities()
    return {"error": "Bot not initialized"}

@app.get("/api/trades")
async def get_trades():
    if bot:
        return bot.get_trade_history()
    return {"error": "Bot not initialized"}

@app.get("/api/config")
async def get_config():
    if bot:
        return bot.get_config()
    return {"error": "Bot not initialized"}

@app.post("/api/config")
async def update_config(config: dict):
    if bot:
        await bot.update_config(config)
        return {"status": "success"}
    return {"error": "Bot not initialized"}

@app.post("/api/trading/toggle")
async def toggle_real_trading():
    if bot:
        current_mode = bot.config.get("enable_real_trading", False)
        bot.config["enable_real_trading"] = not current_mode
        return {
            "status": "success", 
            "real_trading_enabled": bot.config["enable_real_trading"]
        }
    return {"error": "Bot not initialized"}

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    while True:
        try:
            if bot:
                data = {
                    "balances": await bot.get_all_balances(),
                    "prices": await bot.get_current_prices(),
                    "opportunities": bot.get_arbitrage_opportunities(),
                    "trades": bot.get_trade_history()
                }
                await websocket.send_text(json.dumps(data))
            await asyncio.sleep(1)
        except Exception as e:
            logging.error(f"WebSocket error: {e}")
            break

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=5000)
