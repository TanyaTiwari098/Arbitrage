
import asyncio
import json
import os
import time
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import logging
from dataclasses import dataclass
from flask import Flask, render_template, request, jsonify
import ccxt
import pandas as pd
import numpy as np

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@dataclass
class ArbitrageOpportunity:
    buy_exchange: str
    sell_exchange: str
    profit_percentage: float
    buy_price: float
    sell_price: float
    volume: float
    timestamp: datetime

@dataclass
class TradeResult:
    timestamp: datetime
    buy_exchange: str
    sell_exchange: str
    amount: float
    profit: float
    profit_percentage: float
    status: str

class ExchangeManager:
    def __init__(self):
        self.exchanges = {}
        self.api_keys = self.load_api_keys()
        self.initialize_exchanges()
        
    def load_api_keys(self) -> Dict:
        """Load API keys from environment variables or config"""
        return {
            'binance': {
                'apiKey': os.getenv('BINANCE_API_KEY', ''),
                'secret': os.getenv('BINANCE_SECRET', ''),
                'sandbox': False,
                'enableRateLimit': True,
            },
            'kraken': {
                'apiKey': os.getenv('KRAKEN_API_KEY', ''),
                'secret': os.getenv('KRAKEN_SECRET', ''),
                'sandbox': False,
                'enableRateLimit': True,
            },
            'bitget': {
                'apiKey': os.getenv('BITGET_API_KEY', ''),
                'secret': os.getenv('BITGET_SECRET', ''),
                'password': os.getenv('BITGET_PASSPHRASE', ''),
                'sandbox': False,
                'enableRateLimit': True,
            },
            'coinbase': {
                'apiKey': os.getenv('COINBASE_API_KEY', ''),
                'secret': os.getenv('COINBASE_SECRET', ''),
                'password': os.getenv('COINBASE_PASSPHRASE', ''),
                'sandbox': False,
                'enableRateLimit': True,
            }
        }
    
    def initialize_exchanges(self):
        """Initialize exchange connections"""
        try:
            if self.api_keys['binance']['apiKey']:
                self.exchanges['binance'] = ccxt.binance(self.api_keys['binance'])
            if self.api_keys['kraken']['apiKey']:
                self.exchanges['kraken'] = ccxt.kraken(self.api_keys['kraken'])
            if self.api_keys['bitget']['apiKey']:
                self.exchanges['bitget'] = ccxt.bitget(self.api_keys['bitget'])
            if self.api_keys['coinbase']['apiKey']:
                self.exchanges['coinbase'] = ccxt.coinbasepro(self.api_keys['coinbase'])
                
            logger.info(f"Initialized {len(self.exchanges)} exchanges")
        except Exception as e:
            logger.error(f"Error initializing exchanges: {e}")
    
    def get_ticker(self, exchange_name: str, symbol: str) -> Optional[Dict]:
        """Get ticker data from exchange"""
        try:
            if exchange_name in self.exchanges:
                return self.exchanges[exchange_name].fetch_ticker(symbol)
        except Exception as e:
            logger.error(f"Error fetching ticker from {exchange_name}: {e}")
        return None
    
    def get_balance(self, exchange_name: str) -> Optional[Dict]:
        """Get account balance from exchange"""
        try:
            if exchange_name in self.exchanges:
                return self.exchanges[exchange_name].fetch_balance()
        except Exception as e:
            logger.error(f"Error fetching balance from {exchange_name}: {e}")
        return None

class ArbitrageBot:
    def __init__(self):
        self.exchange_manager = ExchangeManager()
        self.symbol = 'ETH/USD'
        self.min_profit_percentage = 0.1  # Default 0.1%
        self.max_position_size = 1000  # USD
        self.running = False
        self.opportunities = []
        self.trade_history = []
        self.price_data = {}
        self.balances = {}
        
    def update_config(self, min_profit: float, max_position: float):
        """Update bot configuration"""
        self.min_profit_percentage = min_profit
        self.max_position_size = max_position
        logger.info(f"Updated config: min_profit={min_profit}%, max_position=${max_position}")
    
    def fetch_prices(self) -> Dict[str, float]:
        """Fetch current prices from all exchanges"""
        prices = {}
        for exchange_name in self.exchange_manager.exchanges.keys():
            ticker = self.exchange_manager.get_ticker(exchange_name, self.symbol)
            if ticker:
                prices[exchange_name] = {
                    'bid': ticker['bid'],
                    'ask': ticker['ask'],
                    'last': ticker['last'],
                    'timestamp': ticker['timestamp']
                }
        return prices
    
    def fetch_balances(self) -> Dict[str, Dict]:
        """Fetch balances from all exchanges"""
        balances = {}
        for exchange_name in self.exchange_manager.exchanges.keys():
            balance = self.exchange_manager.get_balance(exchange_name)
            if balance:
                balances[exchange_name] = {
                    'ETH': balance.get('ETH', {}).get('free', 0),
                    'USD': balance.get('USD', {}).get('free', 0) or balance.get('USDT', {}).get('free', 0),
                    'total_usd': balance.get('total', 0)
                }
        return balances
    
    def find_arbitrage_opportunities(self, prices: Dict) -> List[ArbitrageOpportunity]:
        """Find arbitrage opportunities between exchanges"""
        opportunities = []
        exchanges = list(prices.keys())
        
        for i, buy_exchange in enumerate(exchanges):
            for sell_exchange in exchanges[i+1:]:
                if buy_exchange == sell_exchange:
                    continue
                    
                buy_price = prices[buy_exchange]['ask']
                sell_price = prices[sell_exchange]['bid']
                
                if sell_price > buy_price:
                    profit_percentage = ((sell_price - buy_price) / buy_price) * 100
                    
                    if profit_percentage >= self.min_profit_percentage:
                        opportunities.append(ArbitrageOpportunity(
                            buy_exchange=buy_exchange,
                            sell_exchange=sell_exchange,
                            profit_percentage=profit_percentage,
                            buy_price=buy_price,
                            sell_price=sell_price,
                            volume=min(self.max_position_size / buy_price, 10),  # Max 10 ETH
                            timestamp=datetime.now()
                        ))
                
                # Check reverse direction
                buy_price = prices[sell_exchange]['ask']
                sell_price = prices[buy_exchange]['bid']
                
                if sell_price > buy_price:
                    profit_percentage = ((sell_price - buy_price) / buy_price) * 100
                    
                    if profit_percentage >= self.min_profit_percentage:
                        opportunities.append(ArbitrageOpportunity(
                            buy_exchange=sell_exchange,
                            sell_exchange=buy_exchange,
                            profit_percentage=profit_percentage,
                            buy_price=buy_price,
                            sell_price=sell_price,
                            volume=min(self.max_position_size / buy_price, 10),
                            timestamp=datetime.now()
                        ))
        
        return sorted(opportunities, key=lambda x: x.profit_percentage, reverse=True)
    
    def execute_trade(self, opportunity: ArbitrageOpportunity) -> TradeResult:
        """Execute arbitrage trade (SIMULATION MODE)"""
        # This is simulation mode - replace with real trading logic when ready
        logger.info(f"SIMULATING trade: Buy {opportunity.volume:.4f} ETH on {opportunity.buy_exchange} at ${opportunity.buy_price:.2f}, "
                   f"Sell on {opportunity.sell_exchange} at ${opportunity.sell_price:.2f}, "
                   f"Profit: {opportunity.profit_percentage:.3f}%")
        
        profit = opportunity.volume * (opportunity.sell_price - opportunity.buy_price)
        
        trade_result = TradeResult(
            timestamp=datetime.now(),
            buy_exchange=opportunity.buy_exchange,
            sell_exchange=opportunity.sell_exchange,
            amount=opportunity.volume,
            profit=profit,
            profit_percentage=opportunity.profit_percentage,
            status="SIMULATED"
        )
        
        self.trade_history.append(trade_result)
        return trade_result
    
    def run_arbitrage_cycle(self):
        """Single arbitrage detection cycle"""
        try:
            # Fetch current prices
            prices = self.fetch_prices()
            if not prices:
                return
            
            self.price_data = prices
            
            # Fetch balances
            self.balances = self.fetch_balances()
            
            # Find opportunities
            opportunities = self.find_arbitrage_opportunities(prices)
            self.opportunities = opportunities
            
            # Execute profitable trades (simulation mode)
            for opportunity in opportunities[:3]:  # Limit to top 3 opportunities
                if opportunity.profit_percentage >= self.min_profit_percentage:
                    self.execute_trade(opportunity)
                    
        except Exception as e:
            logger.error(f"Error in arbitrage cycle: {e}")
    
    def start(self):
        """Start the arbitrage bot"""
        self.running = True
        logger.info("Arbitrage bot started")
        
        while self.running:
            self.run_arbitrage_cycle()
            time.sleep(5)  # 5-second interval
    
    def stop(self):
        """Stop the arbitrage bot"""
        self.running = False
        logger.info("Arbitrage bot stopped")

# Initialize bot
arbitrage_bot = ArbitrageBot()

# Flask Web Dashboard
app = Flask(__name__, template_folder='templates', static_folder='static')

@app.route('/')
def dashboard():
    return render_template('dashboard.html')

@app.route('/api/status')
def api_status():
    return jsonify({
        'running': arbitrage_bot.running,
        'exchanges': list(arbitrage_bot.exchange_manager.exchanges.keys()),
        'symbol': arbitrage_bot.symbol,
        'min_profit': arbitrage_bot.min_profit_percentage,
        'max_position': arbitrage_bot.max_position_size
    })

@app.route('/api/prices')
def api_prices():
    return jsonify(arbitrage_bot.price_data)

@app.route('/api/balances')
def api_balances():
    return jsonify(arbitrage_bot.balances)

@app.route('/api/opportunities')
def api_opportunities():
    opportunities = []
    for opp in arbitrage_bot.opportunities[:10]:  # Top 10 opportunities
        opportunities.append({
            'buy_exchange': opp.buy_exchange,
            'sell_exchange': opp.sell_exchange,
            'profit_percentage': round(opp.profit_percentage, 4),
            'buy_price': round(opp.buy_price, 2),
            'sell_price': round(opp.sell_price, 2),
            'volume': round(opp.volume, 4),
            'timestamp': opp.timestamp.isoformat()
        })
    return jsonify(opportunities)

@app.route('/api/trades')
def api_trades():
    trades = []
    for trade in arbitrage_bot.trade_history[-50:]:  # Last 50 trades
        trades.append({
            'timestamp': trade.timestamp.isoformat(),
            'buy_exchange': trade.buy_exchange,
            'sell_exchange': trade.sell_exchange,
            'amount': round(trade.amount, 4),
            'profit': round(trade.profit, 2),
            'profit_percentage': round(trade.profit_percentage, 4),
            'status': trade.status
        })
    return jsonify(trades)

@app.route('/api/config', methods=['POST'])
def update_config():
    data = request.json
    min_profit = float(data.get('min_profit', 0.1))
    max_position = float(data.get('max_position', 1000))
    arbitrage_bot.update_config(min_profit, max_position)
    return jsonify({'status': 'success'})

@app.route('/api/start', methods=['POST'])
def start_bot():
    if not arbitrage_bot.running:
        bot_thread = threading.Thread(target=arbitrage_bot.start)
        bot_thread.daemon = True
        bot_thread.start()
    return jsonify({'status': 'started'})

@app.route('/api/stop', methods=['POST'])
def stop_bot():
    arbitrage_bot.stop()
    return jsonify({'status': 'stopped'})

if __name__ == '__main__':
    # Create templates directory and files
    os.makedirs('templates', exist_ok=True)
    os.makedirs('static', exist_ok=True)
    
    app.run(host='0.0.0.0', port=5000, debug=True)
