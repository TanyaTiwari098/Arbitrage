
import asyncio
import logging
import time
from datetime import datetime, timedelta
import ccxt
import aiohttp
import json
from typing import Dict, List, Optional
import numpy as np
import hashlib
import hmac
import base64
from config import Config

class ArbitrageBot:
    def __init__(self):
        self.exchanges = {}
        self.balances = {}
        self.prices = {}
        self.opportunities = []
        self.trades = []
        self.config = {
            "min_profit_threshold": Config.TRADING["min_profit_threshold"],
            "max_trade_amount": Config.TRADING["max_trade_amount"],
            "min_trade_amount": Config.TRADING["min_trade_amount"],
            "enable_real_trading": Config.TRADING["enable_real_trading"],
            "risk_management": Config.RISK_MANAGEMENT,
            "exchanges": Config.EXCHANGES
        }
        self.running = False
        self.daily_pnl = 0
        
    async def start(self):
        """Start the arbitrage bot"""
        self.running = True
        await self.initialize_exchanges()
        
        # Start monitoring tasks
        asyncio.create_task(self.price_monitor())
        asyncio.create_task(self.balance_monitor())
        asyncio.create_task(self.arbitrage_scanner())
        
        logging.info("Arbitrage bot started successfully")
    
    async def initialize_exchanges(self):
        """Initialize exchange connections"""
        try:
            # Binance
            if self.config["exchanges"]["binance"]["enabled"]:
                self.exchanges["binance"] = ccxt.binance({
                    'apiKey': self.config["exchanges"]["binance"]["api_key"],
                    'secret': self.config["exchanges"]["binance"]["secret"],
                    'sandbox': self.config["exchanges"]["binance"].get("testnet", False),
                    'enableRateLimit': True,
                    'options': {
                        'adjustForTimeDifference': True,
                        'recvWindow': 60000,
                    }
                })
                logging.info("Binance exchange initialized")
            
            # Kraken
            if self.config["exchanges"]["kraken"]["enabled"]:
                self.exchanges["kraken"] = ccxt.kraken({
                    'apiKey': self.config["exchanges"]["kraken"]["api_key"],
                    'secret': self.config["exchanges"]["kraken"]["secret"],
                    'enableRateLimit': True,
                    'options': {
                        'adjustForTimeDifference': True,
                    }
                })
                # Test Kraken connection
                try:
                    await asyncio.get_event_loop().run_in_executor(None, self.exchanges["kraken"].load_markets)
                    logging.info("Kraken exchange initialized and markets loaded")
                except Exception as e:
                    logging.error(f"Kraken market loading failed: {e}")
            
            # Bitget
            if self.config["exchanges"]["bitget"]["enabled"]:
                self.exchanges["bitget"] = ccxt.bitget({
                    'apiKey': self.config["exchanges"]["bitget"]["api_key"],
                    'secret': self.config["exchanges"]["bitget"]["secret"],
                    'password': self.config["exchanges"]["bitget"]["passphrase"],
                    'enableRateLimit': True,
                    'options': {
                        'adjustForTimeDifference': True,
                    }
                })
                logging.info("Bitget exchange initialized")
            
            # Coinbase (optional)
            if self.config["exchanges"]["coinbase"]["enabled"]:
                self.exchanges["coinbase"] = ccxt.coinbase({
                    'apiKey': self.config["exchanges"]["coinbase"]["api_key"],
                    'secret': self.config["exchanges"]["coinbase"]["secret"],
                    'enableRateLimit': True,
                    'options': {
                        'adjustForTimeDifference': True,
                    }
                })
                logging.info("Coinbase exchange initialized")
                
        except Exception as e:
            logging.error(f"Error initializing exchanges: {e}")
    
    async def get_all_balances(self):
        """Get balances from all exchanges"""
        balances = {}
        for exchange_name, exchange in self.exchanges.items():
            try:
                balance = await self.get_exchange_balance(exchange)
                balances[exchange_name] = balance
            except Exception as e:
                logging.error(f"Error getting balance from {exchange_name}: {e}")
                balances[exchange_name] = {"error": str(e)}
        
        self.balances = balances
        return balances
    
    async def get_exchange_balance(self, exchange):
        """Get balance from specific exchange with retry logic"""
        max_retries = 3
        retry_delay = 2
        
        for attempt in range(max_retries):
            try:
                # Add a small delay before each attempt to avoid nonce issues
                if attempt > 0:
                    await asyncio.sleep(retry_delay * attempt)
                
                # Use asyncio to run the synchronous fetch_balance in a thread
                balance = await asyncio.get_event_loop().run_in_executor(None, exchange.fetch_balance)
                
                # Get current ETH price for USD calculation
                eth_price = 3000  # Default fallback
                try:
                    if hasattr(exchange, 'id') and exchange.id in self.prices:
                        price_data = self.prices[exchange.id]
                        if 'last' in price_data and price_data['last']:
                            eth_price = float(price_data['last'])
                except:
                    pass
                
                # Calculate total USD value
                total_usd = 0
                if 'total' in balance:
                    total_usd += balance['total'].get('USD', 0)
                    total_usd += balance['total'].get('USDT', 0)
                    total_usd += balance['total'].get('USDC', 0)
                    total_usd += balance['total'].get('ETH', 0) * eth_price
                
                return {
                    "total_usd": round(total_usd, 2),
                    "eth": {
                        "free": round(balance.get('free', {}).get('ETH', 0), 6),
                        "used": round(balance.get('used', {}).get('ETH', 0), 6),
                        "total": round(balance.get('total', {}).get('ETH', 0), 6)
                    },
                    "usdt": {
                        "free": round(balance.get('free', {}).get('USDT', 0), 2),
                        "used": round(balance.get('used', {}).get('USDT', 0), 2),
                        "total": round(balance.get('total', {}).get('USDT', 0), 2)
                    },
                    "usd": {
                        "free": round(balance.get('free', {}).get('USD', 0), 2),
                        "used": round(balance.get('used', {}).get('USD', 0), 2),
                        "total": round(balance.get('total', {}).get('USD', 0), 2)
                    },
                    "usdc": {
                        "free": round(balance.get('free', {}).get('USDC', 0), 2),
                        "used": round(balance.get('used', {}).get('USDC', 0), 2),
                        "total": round(balance.get('total', {}).get('USDC', 0), 2)
                    }
                }
                
            except Exception as e:
                error_msg = str(e).lower()
                if attempt < max_retries - 1 and ('nonce' in error_msg or 'rate limit' in error_msg):
                    logging.warning(f"Retrying balance fetch (attempt {attempt + 1}/{max_retries}): {e}")
                    continue
                else:
                    logging.error(f"Error fetching balance after {attempt + 1} attempts: {e}")
                    return {"error": str(e)}
        
        return {"error": "Max retries exceeded"}
    
    async def get_current_prices(self):
        """Get current ETH/USD prices from all exchanges"""
        prices = {}
        
        # Define preferred symbols for each exchange
        symbol_preferences = {
            'binance': ['ETH/USDT', 'ETH/USD'],
            'kraken': ['ETH/USD', 'ETH/USDT'],
            'bitget': ['ETH/USDT', 'ETH/USD'],
            'coinbase': ['ETH/USD', 'ETH/USDT']
        }
        
        for exchange_name, exchange in self.exchanges.items():
            symbols_to_try = symbol_preferences.get(exchange_name, ['ETH/USD', 'ETH/USDT'])
            
            for symbol in symbols_to_try:
                try:
                    ticker = await asyncio.get_event_loop().run_in_executor(None, exchange.fetch_ticker, symbol)
                    prices[exchange_name] = {
                        "symbol": symbol,
                        "bid": round(float(ticker['bid']) if ticker['bid'] else 0, 2),
                        "ask": round(float(ticker['ask']) if ticker['ask'] else 0, 2),
                        "last": round(float(ticker['last']) if ticker['last'] else 0, 2),
                        "timestamp": ticker['timestamp'],
                        "spread": round(float(ticker['ask'] - ticker['bid']) if ticker['ask'] and ticker['bid'] else 0, 4)
                    }
                    break  # Success, move to next exchange
                except Exception as e:
                    if symbol == symbols_to_try[-1]:  # Last symbol failed
                        logging.warning(f"Could not get price from {exchange_name}: {e}")
                        prices[exchange_name] = {"error": str(e)}
                    continue
        
        self.prices = prices
        return prices
    
    async def price_monitor(self):
        """Monitor prices continuously"""
        while self.running:
            await self.get_current_prices()
            await asyncio.sleep(1)  # Update every second
    
    async def balance_monitor(self):
        """Monitor balances continuously"""
        while self.running:
            await self.get_all_balances()
            await asyncio.sleep(30)  # Update every 30 seconds
    
    async def arbitrage_scanner(self):
        """Scan for arbitrage opportunities"""
        while self.running:
            try:
                await self.find_arbitrage_opportunities()
                await asyncio.sleep(5)  # Scan every 5 seconds
            except Exception as e:
                logging.error(f"Error in arbitrage scanner: {e}")
                await asyncio.sleep(10)
    
    async def find_arbitrage_opportunities(self):
        """Find arbitrage opportunities between exchanges"""
        if len(self.prices) < 2:
            return
        
        opportunities = []
        exchanges = list(self.prices.keys())
        
        for i in range(len(exchanges)):
            for j in range(i + 1, len(exchanges)):
                exchange1 = exchanges[i]
                exchange2 = exchanges[j]
                
                if "error" in self.prices[exchange1] or "error" in self.prices[exchange2]:
                    continue
                
                price1 = self.prices[exchange1].get("ask", 0)
                price2 = self.prices[exchange2].get("bid", 0)
                
                if price1 and price2 and price1 > 0 and price2 > 0:
                    # Calculate profit opportunity
                    profit_pct = ((price2 - price1) / price1) * 100
                    
                    if profit_pct > self.config["min_profit_threshold"]:
                        opportunity = {
                            "buy_exchange": exchange1,
                            "sell_exchange": exchange2,
                            "buy_price": price1,
                            "sell_price": price2,
                            "profit_pct": profit_pct,
                            "timestamp": datetime.now().isoformat()
                        }
                        opportunities.append(opportunity)
                        
                        # Execute trade if conditions are met
                        if self.should_execute_trade(opportunity):
                            await self.execute_arbitrage_trade(opportunity)
        
        self.opportunities = opportunities
    
    def should_execute_trade(self, opportunity):
        """Determine if trade should be executed based on risk management"""
        # Check daily loss limit
        if self.daily_pnl < -self.config["risk_management"]["max_daily_loss"]:
            return False
        
        # Check profit threshold
        if opportunity["profit_pct"] < self.config["min_profit_threshold"]:
            return False
        
        return True
    
    async def execute_arbitrage_trade(self, opportunity):
        """Execute arbitrage trade with safety checks"""
        try:
            # Safety check: Don't execute trades in demo mode unless explicitly enabled
            if not self.config.get("enable_real_trading", False):
                logging.info(f"Demo mode: Would execute trade - {opportunity}")
                
                # Create simulated trade for demo
                trade = {
                    "timestamp": datetime.now().isoformat(),
                    "buy_exchange": opportunity["buy_exchange"],
                    "sell_exchange": opportunity["sell_exchange"],
                    "amount": min(self.config["max_trade_amount"], 100),
                    "buy_price": opportunity["buy_price"],
                    "sell_price": opportunity["sell_price"],
                    "profit_pct": opportunity["profit_pct"],
                    "profit_usd": (opportunity["sell_price"] - opportunity["buy_price"]) * 100,
                    "buy_order_id": f"demo_{int(time.time())}",
                    "sell_order_id": f"demo_{int(time.time())}_sell",
                    "status": "demo_completed"
                }
                self.trades.append(trade)
                return
            
            buy_exchange = self.exchanges[opportunity["buy_exchange"]]
            sell_exchange = self.exchanges[opportunity["sell_exchange"]]
            
            # Calculate trade amount based on available balance
            trade_amount_usd = min(
                self.config["max_trade_amount"],
                self.get_max_trade_amount(opportunity)
            )
            
            if trade_amount_usd < self.config.get("min_trade_amount", 10):
                logging.info(f"Trade amount too small: ${trade_amount_usd}")
                return
            
            # Convert USD amount to ETH amount
            eth_amount = trade_amount_usd / opportunity["buy_price"]
            
            # Get the correct symbol for each exchange
            buy_symbol = self.prices[opportunity["buy_exchange"]].get("symbol", "ETH/USDT")
            sell_symbol = self.prices[opportunity["sell_exchange"]].get("symbol", "ETH/USDT")
            
            # Execute buy order
            logging.info(f"Placing buy order: {eth_amount} ETH on {opportunity['buy_exchange']}")
            buy_order = await asyncio.get_event_loop().run_in_executor(
                None, buy_exchange.create_market_buy_order, buy_symbol, eth_amount
            )
            
            # Wait a moment for the buy order to complete
            await asyncio.sleep(1)
            
            # Execute sell order
            logging.info(f"Placing sell order: {eth_amount} ETH on {opportunity['sell_exchange']}")
            sell_order = await asyncio.get_event_loop().run_in_executor(
                None, sell_exchange.create_market_sell_order, sell_symbol, eth_amount
            )
            
            # Record trade
            profit_usd = (opportunity["sell_price"] - opportunity["buy_price"]) * eth_amount
            trade = {
                "timestamp": datetime.now().isoformat(),
                "buy_exchange": opportunity["buy_exchange"],
                "sell_exchange": opportunity["sell_exchange"],
                "amount_eth": round(eth_amount, 6),
                "amount_usd": round(trade_amount_usd, 2),
                "buy_price": opportunity["buy_price"],
                "sell_price": opportunity["sell_price"],
                "profit_pct": opportunity["profit_pct"],
                "profit_usd": round(profit_usd, 2),
                "buy_order_id": buy_order['id'],
                "sell_order_id": sell_order['id'],
                "buy_symbol": buy_symbol,
                "sell_symbol": sell_symbol,
                "status": "completed"
            }
            
            self.trades.append(trade)
            self.daily_pnl += trade["profit_usd"]
            
            logging.info(f"Executed arbitrage trade: Profit ${profit_usd:.2f}")
            
        except Exception as e:
            logging.error(f"Error executing arbitrage trade: {e}")
            
            # Record failed trade
            trade = {
                "timestamp": datetime.now().isoformat(),
                "buy_exchange": opportunity["buy_exchange"],
                "sell_exchange": opportunity["sell_exchange"],
                "amount_usd": 0,
                "buy_price": opportunity["buy_price"],
                "sell_price": opportunity["sell_price"],
                "profit_pct": opportunity["profit_pct"],
                "profit_usd": 0,
                "error": str(e),
                "status": "failed"
            }
            self.trades.append(trade)
    
    def get_max_trade_amount(self, opportunity):
        """Calculate maximum trade amount based on available balance"""
        buy_exchange_balance = self.balances.get(opportunity["buy_exchange"], {})
        sell_exchange_balance = self.balances.get(opportunity["sell_exchange"], {})
        
        # Get available USD for buying
        usd_available = buy_exchange_balance.get("usd", {}).get("free", 0)
        usdt_available = buy_exchange_balance.get("usdt", {}).get("free", 0)
        max_buy = max(usd_available, usdt_available)
        
        # Get available ETH for selling
        eth_available = sell_exchange_balance.get("eth", {}).get("free", 0)
        max_sell = eth_available * opportunity["sell_price"]
        
        return min(max_buy, max_sell) * self.config["risk_management"]["max_position_size"]
    
    def get_arbitrage_opportunities(self):
        """Get current arbitrage opportunities"""
        return self.opportunities
    
    def get_trade_history(self):
        """Get trade history"""
        return self.trades[-50:]  # Return last 50 trades
    
    def get_config(self):
        """Get current configuration"""
        return self.config
    
    async def update_config(self, new_config):
        """Update configuration"""
        self.config.update(new_config)
        # Reinitialize exchanges if API keys changed
        await self.initialize_exchanges()
