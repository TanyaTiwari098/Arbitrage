// WebSocket connection
let ws;
let reconnectInterval = 5000;
let reconnectTimer;

// Data storage
let currentData = {
    balances: {},
    prices: {},
    opportunities: [],
    trades: []
};

// Initialize dashboard
document.addEventListener('DOMContentLoaded', function() {
    initializeWebSocket();
    loadConfiguration();

    // Set up auto-refresh
    setInterval(refreshData, 30000); // Refresh every 30 seconds
});

function initializeWebSocket() {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    ws = new WebSocket(wsUrl);

    ws.onopen = function() {
        console.log('WebSocket connected');
        updateStatus('Active', true);
        if (reconnectTimer) {
            clearTimeout(reconnectTimer);
            reconnectTimer = null;
        }
    };

    ws.onmessage = function(event) {
        try {
            const data = JSON.parse(event.data);
            currentData = data;
            updateDashboard(data);
        } catch (error) {
            console.error('Error parsing WebSocket message:', error);
        }
    };

    ws.onclose = function() {
        console.log('WebSocket disconnected');
        updateStatus('Disconnected', false);

        // Attempt to reconnect
        reconnectTimer = setTimeout(() => {
            console.log('Attempting to reconnect...');
            initializeWebSocket();
        }, reconnectInterval);
    };

    ws.onerror = function(error) {
        console.error('WebSocket error:', error);
        updateStatus('Error', false);
    };
}

function updateStatus(text, isActive) {
    const statusDot = document.getElementById('status-dot');
    const statusText = document.getElementById('status-text');

    statusText.textContent = text;

    if (isActive) {
        statusDot.classList.add('active');
    } else {
        statusDot.classList.remove('active');
    }
}

function updateDashboard(data) {
    updateBalances(data.balances);
    updatePrices(data.prices);
    updateOpportunities(data.opportunities);
    updateTrades(data.trades);
    updateProfitChart(data.trades);
}

function updateBalances(balances) {
    const container = document.getElementById('balance-grid');
    container.innerHTML = '';

    const exchangeOrder = ['binance', 'kraken', 'bitget', 'coinbase'];

    exchangeOrder.forEach(exchange => {
        if (balances[exchange] && !balances[exchange].error) {
            const balance = balances[exchange];
            const card = createBalanceCard(exchange, balance);
            container.appendChild(card);
        }
    });
}

function createBalanceCard(exchange, balance) {
    const card = document.createElement('div');
    card.className = `balance-card ${exchange}`;

    const totalUSD = balance.total_usd || 0;
    const ethBalance = balance.eth?.total || 0;
    const usdBalance = balance.usd?.total || 0;
    const usdtBalance = balance.usdt?.total || 0;

    card.innerHTML = `
        <div class="exchange-name">${exchange}</div>
        <div class="balance-row">
            <span class="currency">Total Value</span>
            <span class="amount">$${totalUSD.toFixed(2)}</span>
        </div>
        <div class="balance-row">
            <span class="currency">ETH</span>
            <span class="amount">${ethBalance.toFixed(6)}</span>
        </div>
        <div class="balance-row">
            <span class="currency">USD</span>
            <span class="amount">$${usdBalance.toFixed(2)}</span>
        </div>
        <div class="balance-row">
            <span class="currency">USDT</span>
            <span class="amount">${usdtBalance.toFixed(2)}</span>
        </div>
    `;

    return card;
}

function updatePrices(prices) {
    const container = document.getElementById('price-grid');
    container.innerHTML = '';

    Object.keys(prices).forEach(exchange => {
        if (!prices[exchange].error) {
            const price = prices[exchange];
            const card = createPriceCard(exchange, price);
            container.appendChild(card);
        }
    });
}

function createPriceCard(exchange, price) {
    const card = document.createElement('div');
    card.className = 'price-card';

    const lastPrice = price.last || 0;
    const bid = price.bid || 0;
    const ask = price.ask || 0;
    const spread = ((ask - bid) / bid * 100).toFixed(3);

    card.innerHTML = `
        <div class="price-exchange">${exchange}</div>
        <div class="price-value">$${lastPrice.toFixed(2)}</div>
        <div class="price-change">
            Bid: $${bid.toFixed(2)} | Ask: $${ask.toFixed(2)}<br>
            Spread: ${spread}%
        </div>
    `;

    return card;
}

function updateOpportunities(opportunities) {
    const container = document.getElementById('opportunities-container');
    container.innerHTML = '';

    if (!opportunities || opportunities.length === 0) {
        container.innerHTML = '<div class="no-data">No arbitrage opportunities found</div>';
        return;
    }

    opportunities.forEach(opp => {
        const card = createOpportunityCard(opp);
        container.appendChild(card);
    });
}

function createOpportunityCard(opportunity) {
    const card = document.createElement('div');
    card.className = 'opportunity-card';

    const profitUSD = ((opportunity.sell_price - opportunity.buy_price) * 100).toFixed(2);

    card.innerHTML = `
        <div class="opportunity-info">
            <div class="opportunity-exchanges">
                ${opportunity.buy_exchange.toUpperCase()}
                <i class="fas fa-arrow-right opportunity-arrow"></i>
                ${opportunity.sell_exchange.toUpperCase()}
            </div>
            <div class="price-info">
                Buy: $${opportunity.buy_price.toFixed(2)} | Sell: $${opportunity.sell_price.toFixed(2)}
            </div>
        </div>
        <div class="opportunity-profit">
            <div class="profit-percentage">${opportunity.profit_pct.toFixed(3)}%</div>
            <div class="profit-amount">Est. $${profitUSD} profit</div>
        </div>
    `;

    return card;
}

function updateTrades(trades) {
    const tbody = document.getElementById('trades-tbody');
    tbody.innerHTML = '';

    if (!trades || trades.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="no-data">No trades executed yet</td></tr>';
        return;
    }

    trades.slice(-10).reverse().forEach(trade => {
        const row = createTradeRow(trade);
        tbody.appendChild(row);
    });
}

function createTradeRow(trade) {
    const row = document.createElement('tr');

    const timestamp = new Date(trade.timestamp).toLocaleString();
    const profitClass = trade.profit_usd >= 0 ? 'profit-positive' : 'profit-negative';
    const statusClass = trade.status === 'completed' ? 'status-completed' : 'status-pending';

    row.innerHTML = `
        <td>${timestamp}</td>
        <td>${trade.buy_exchange.toUpperCase()}</td>
        <td>${trade.sell_exchange.toUpperCase()}</td>
        <td>$${trade.amount.toFixed(2)}</td>
        <td class="${profitClass}">${trade.profit_pct.toFixed(3)}%</td>
        <td class="${profitClass}">$${trade.profit_usd.toFixed(2)}</td>
        <td><span class="${statusClass}">${trade.status}</span></td>
    `;

    return row;
}

function updateProfitChart(trades) {
    if (!trades || trades.length === 0) {
        document.getElementById('profit-chart').innerHTML = '<div class="no-data">No trade data available for chart</div>';
        return;
    }

    const timestamps = trades.map(trade => new Date(trade.timestamp));
    const cumulativeProfit = [];
    let total = 0;

    trades.forEach(trade => {
        total += trade.profit_usd;
        cumulativeProfit.push(total);
    });

    const trace = {
        x: timestamps,
        y: cumulativeProfit,
        type: 'scatter',
        mode: 'lines+markers',
        name: 'Cumulative Profit',
        line: {
            color: '#27ae60',
            width: 3
        },
        marker: {
            color: '#27ae60',
            size: 6
        }
    };

    const layout = {
        title: {
            text: 'Cumulative Profit Over Time',
            font: { size: 18, color: '#2c3e50' }
        },
        xaxis: {
            title: 'Time',
            gridcolor: '#ecf0f1'
        },
        yaxis: {
            title: 'Profit (USD)',
            gridcolor: '#ecf0f1'
        },
        plot_bgcolor: 'white',
        paper_bgcolor: 'transparent',
        margin: { t: 50, r: 30, b: 50, l: 70 }
    };

    Plotly.newPlot('profit-chart', [trace], layout, {responsive: true});
}

async function loadConfiguration() {
    try {
        const response = await fetch('/api/config');
        const config = await response.json();

        document.getElementById('min-profit').value = config.min_profit_threshold;
        document.getElementById('max-trade').value = config.max_trade_amount;
        document.getElementById('max-loss').value = config.risk_management.max_daily_loss;
        document.getElementById('position-size').value = config.risk_management.max_position_size;
        updateTradingModeDisplay(config.enable_real_trading || false);
    } catch (error) {
        console.error('Error loading configuration:', error);
    }
}

async function updateConfig() {
    const config = {
        min_profit_threshold: parseFloat(document.getElementById('min-profit').value),
        max_trade_amount: parseFloat(document.getElementById('max-trade').value),
        risk_management: {
            max_daily_loss: parseFloat(document.getElementById('max-loss').value),
            max_position_size: parseFloat(document.getElementById('position-size').value)
        }
    };

    try {
        const response = await fetch('/api/config', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(config)
        });

        if (response.ok) {
            alert('Configuration updated successfully!');
        } else {
            alert('Error updating configuration');
        }
    } catch (error) {
        console.error('Error updating configuration:', error);
        alert('Error updating configuration');
    }
}

async function refreshData() {
    try {
        const [balances, prices, opportunities, trades] = await Promise.all([
            fetch('/api/balances').then(r => r.json()),
            fetch('/api/prices').then(r => r.json()),
            fetch('/api/opportunities').then(r => r.json()),
            fetch('/api/trades').then(r => r.json())
        ]);

        const data = { balances, prices, opportunities, trades };
        currentData = data;
        updateDashboard(data);
    } catch (error) {
        console.error('Error refreshing data:', error);
    }
}

        function toggleTradingMode() {
            fetch('/api/trading/toggle', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    updateTradingModeDisplay(data.real_trading_enabled);
                    alert(`Trading mode switched to: ${data.real_trading_enabled ? 'LIVE' : 'DEMO'}`);
                } else {
                    alert('Error toggling trading mode');
                }
            });
        }

        function updateTradingModeDisplay(isRealTrading) {
            const statusElement = document.getElementById('tradingModeStatus');
            const toggleButton = document.getElementById('toggleTradingMode');

            if (isRealTrading) {
                statusElement.textContent = 'LIVE TRADING';
                statusElement.className = 'trading-mode-status live';
                toggleButton.textContent = 'Switch to Demo';
                toggleButton.className = 'trading-toggle-btn enabled';
            } else {
                statusElement.textContent = 'DEMO MODE';
                statusElement.className = 'trading-mode-status demo';
                toggleButton.textContent = 'Enable Real Trading';
                toggleButton.className = 'trading-toggle-btn';
            }
        }