
import os
from typing import Dict

class Config:
    # Exchange API Configuration
    EXCHANGES = {
        "binance": {
            "enabled": True,
            "api_key": os.getenv("BINANCE_API_KEY", "eTWN3IZCEFBTckbX5rWQBy1hAY3F2s1pkIEo0KoSDFusJomtWrWVElkM0y3OKpD4"),
            "secret": os.getenv("BINANCE_SECRET", "uo8VwexHAMyVAq3rylssKM0B2Tk79hDj92A98QeH5C3fs62QWZuCkJTdKUnCLpQP"),
            "testnet": os.getenv("BINANCE_TESTNET", "false").lower() == "true"
        },
        "kraken": {
            "enabled": True,
            "api_key": os.getenv("KRAKEN_API_KEY", "QcRZmNJfgHT6R8ZuaPWubNxc6C32Z6OIJQRXt9bXNGxOupTL0rZ+t3d0"),
            "secret": os.getenv("KRAKEN_SECRET", "yMaHnk3ZORUKQrp+yoVimHHwAKOZoYEh4bNy6rVpugzaVpWeKIo/9tZmrndOr7mRTjYVV2cgQMV9L53ez+uAqg=="),
        },
        "bitget": {
            "enabled": True,
            "api_key": os.getenv("BITGET_API_KEY", "bg_afe2015a0280858f5c5e96f71825a225"),
            "secret": os.getenv("BITGET_SECRET", "2a601d104d14aeb27d1a73809b24055cf3b2a4dadd94ccc473023ee3313c0a8a"),
            "passphrase": os.getenv("BITGET_PASSPHRASE", "imthebest"),
        },
        "coinbase": {
            "enabled": False,
            "api_key": os.getenv("COINBASE_API_KEY", ""),
            "secret": os.getenv("COINBASE_SECRET", ""),
        }
    }
    
    # Trading Configuration
    TRADING = {
        "symbol": "ETH/USD",
        "min_profit_threshold": 0.5,  # 0.5%
        "max_trade_amount": 1000,     # USD
        "min_trade_amount": 10,       # USD
        "enable_real_trading": False, # Set to True to enable real trading (default: demo mode)
    }
    
    # Risk Management
    RISK_MANAGEMENT = {
        "max_daily_loss": 100,        # USD
        "max_position_size": 0.1,     # 10% of balance
        "stop_loss": 2.0,             # 2%
        "max_open_positions": 3,
    }
    
    # WebSocket and API Configuration
    WEBSOCKET = {
        "reconnect_interval": 5,      # seconds
        "heartbeat_interval": 30,     # seconds
    }
    
    # Logging Configuration
    LOGGING = {
        "level": "INFO",
        "file": "arbitrage_bot.log",
        "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    }

def get_exchange_config(exchange_name: str) -> Dict:
    """Get configuration for specific exchange"""
    return Config.EXCHANGES.get(exchange_name, {})

def is_exchange_enabled(exchange_name: str) -> bool:
    """Check if exchange is enabled"""
    config = get_exchange_config(exchange_name)
    return config.get("enabled", False) and config.get("api_key", "") != ""
